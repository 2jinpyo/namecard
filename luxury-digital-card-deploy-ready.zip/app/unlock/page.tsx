"use client";
import { useState } from "react";
import { LockKeyhole, ArrowRight } from "lucide-react";

export default function UnlockPage() {
  const [password,setPassword] = useState("");
  const [error,setError] = useState("");
  const [busy,setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      const res = await fetch("/api/unlock", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({password})
      });
      const data = await res.json();
      if (!res.ok) setError(data.error || "접속할 수 없습니다.");
      else window.location.href = "/";
    } catch { setError("연결에 실패했습니다. 다시 시도해 주세요."); }
    setBusy(false);
  }
  return <main className="unlock-wrap">
    <section className="unlock-card">
      <div className="lock-mark"><LockKeyhole size={24}/></div>
      <div className="admin-kicker">PRIVATE DIGITAL IDENTITY</div>
      <h1>Welcome</h1>
      <p>명함을 확인하려면 비밀번호를 입력하세요.</p>
      <form onSubmit={submit}>
        <input autoFocus inputMode="numeric" type="password" value={password}
          onChange={e=>setPassword(e.target.value)} placeholder="PASSWORD" aria-label="비밀번호" required/>
        <button disabled={busy}><span>입장하기</span><ArrowRight size={17}/></button>
      </form>
      {error && <div className="unlock-error">{error}</div>}
      <div className="unlock-foot">AUTHORIZED ACCESS ONLY</div>
    </section>
  </main>;
}