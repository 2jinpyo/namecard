import { NextRequest, NextResponse } from "next/server";
import { createHmac } from "crypto";

export async function POST(req: NextRequest) {
  const secret = process.env.SITE_PASSWORD;
  if (!secret) return NextResponse.json({ error: "사이트 비밀번호 설정이 필요합니다." }, { status: 503 });
  const body = await req.json().catch(() => ({}));
  if (typeof body.password !== "string" || body.password !== secret) {
    return NextResponse.json({ error: "비밀번호가 올바르지 않습니다." }, { status: 401 });
  }
  const timestamp = Date.now().toString();
  const signature = createHmac("sha256", secret).update(timestamp).digest("base64url");
  const response = NextResponse.json({ ok: true });
  response.cookies.set("digital_card_access", `${timestamp}.${signature}`, {
    httpOnly: true, secure: process.env.NODE_ENV === "production",
    sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 7
  });
  return response;
}