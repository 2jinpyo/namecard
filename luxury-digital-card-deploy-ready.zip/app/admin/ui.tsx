"use client";
import { useEffect, useState } from "react";
import { supabaseBrowser } from "../../lib/supabase";
import { Save, LogIn, LogOut, Eye, EyeOff } from "lucide-react";

const initial: any = {
  name: "YOUR NAME", title: "YOUR POSITION", company: "YOUR COMPANY",
  bio: "당신을 소개하는 한 문장을 입력하세요.", phone: "", email: "",
  instagram: "", website: "", address: "", avatar_url: "", accent: "#c8a96e",
  show_phone: true, show_email: true, show_instagram: true, show_website: true, show_address: false
};
const fields = [
  ["name","이름"],["title","직책 / 역할"],["company","회사 / 브랜드"],["bio","소개 문구"],
  ["phone","전화번호"],["email","이메일"],["instagram","인스타그램 아이디"],["website","웹사이트 URL"],
  ["address","주소"],["avatar_url","프로필 이미지 URL"]
];
export default function Admin() {
  const [db] = useState(() => supabaseBrowser());
  const [user,setUser] = useState<any>(null);
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [data,setData] = useState<any>(initial);
  const [status,setStatus] = useState("");
  const [busy,setBusy] = useState(false);

  useEffect(() => {
    db.auth.getUser().then(({data}) => setUser(data.user));
    const { data: listener } = db.auth.onAuthStateChange((_event, session) => setUser(session?.user ?? null));
    return () => listener.subscription.unsubscribe();
  },[db]);

  useEffect(() => {
    if (!user) return;
    db.from("profiles").select("*").eq("id","owner").maybeSingle().then(({data,error}) => {
      if (data) setData({...initial,...data});
      else if (error) setStatus(error.message);
    });
  },[user,db]);

  async function login(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setStatus("");
    const {data,error} = await db.auth.signInWithPassword({email,password});
    if (error) setStatus(error.message); else setUser(data.user);
    setBusy(false);
  }
  async function save() {
    setBusy(true); setStatus("");
    const {error} = await db.from("profiles").upsert({id:"owner",...data,updated_at:new Date().toISOString()});
    setStatus(error ? `저장 실패: ${error.message}` : "저장 완료 · 공개 명함에 반영됐어요.");
    setBusy(false);
  }
  if (!user) return <main className="admin-wrap"><div className="admin-panel">
    <div className="admin-kicker">PRIVATE ACCESS</div><h1>관리자 로그인</h1>
    <p>명함 소유자만 편집할 수 있습니다.</p>
    <form onSubmit={login}>
      <label>이메일<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></label>
      <label>비밀번호<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required/></label>
      <button disabled={busy}><LogIn size={17}/> 로그인</button>
    </form>{status && <small>{status}</small>}
    <a className="back" href="/">공개 명함 보기 ↗</a>
  </div></main>;

  return <main className="admin-wrap"><div className="editor">
    <header className="editor-head"><div><div className="admin-kicker">OWNER CONSOLE</div><h1>명함 편집</h1><p>수정 후 저장하면 공개 명함에 반영됩니다.</p></div>
      <button className="ghost" onClick={()=>db.auth.signOut()}><LogOut size={16}/> 로그아웃</button></header>
    <div className="editor-grid">
      {fields.map(([key,label])=><label key={key}>{label}
        {key==="bio" ? <textarea value={data[key]||""} onChange={e=>setData({...data,[key]:e.target.value})}/> :
        <input value={data[key]||""} onChange={e=>setData({...data,[key]:e.target.value})}/>}
      </label>)}
    </div>
    <h2>표시 설정</h2>
    <div className="toggles">{[["show_phone","전화번호"],["show_email","이메일"],["show_instagram","인스타그램"],["show_website","웹사이트"],["show_address","주소"]].map(([k,l])=>
      <label className="toggle" key={k}><input type="checkbox" checked={!!data[k]} onChange={e=>setData({...data,[k]:e.target.checked})}/>{data[k]?<Eye size={16}/>:<EyeOff size={16}/>} {l}</label>)}</div>
    <label className="accent">포인트 컬러<input type="color" value={data.accent||"#c8a96e"} onChange={e=>setData({...data,accent:e.target.value})}/></label>
    <button className="save-btn" onClick={save} disabled={busy}><Save size={17}/>{busy?"처리 중...":"변경사항 저장"}</button>
    {status && <p className="status">{status}</p>}
    <a className="back" href="/">공개 명함 보기 ↗</a>
  </div></main>;
}