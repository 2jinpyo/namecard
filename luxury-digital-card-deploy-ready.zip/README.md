# Luxury Digital Business Card

블랙 & 골드 스타일의 NFC용 디지털 명함 웹앱입니다.

## 기능
- `/` 공개 명함 페이지 (사이트 비밀번호 통과 후 열람)
- `/unlock` 사이트 비밀번호 화면
- `/admin` 소유자 로그인 후 명함 편집
- 이름, 직책, 회사, 소개, 연락처, SNS, 주소, 프로필 이미지 URL 편집
- 연락처 `.vcf` 저장
- 항목별 공개/숨김
- Supabase DB 저장 및 공개 페이지 반영
- 사이트 비밀번호는 서버에서 검증하며 통과 쿠키는 7일 유지

## 1. 계정 준비
배포하려면 본인 명의로 아래 무료 계정을 준비해야 합니다.
- Supabase: https://supabase.com
- Vercel: https://vercel.com
- GitHub: https://github.com

이 프로젝트는 사용자 계정에 로그인하거나 대신 약관에 동의할 수 없으므로 계정 생성 및 배포 승인은 사용자가 직접 해야 합니다.

## 2. Supabase 설정
1. Supabase에서 New project 생성
2. SQL Editor에서 `supabase/schema.sql` 파일 내용을 붙여넣고 Run
3. Authentication > Users에서 소유자 이메일/비밀번호 계정 생성
4. Authentication 설정에서 공개 회원가입을 비활성화
5. Project Settings > API에서 Project URL과 anon/public key 복사

## 3. GitHub 업로드
1. 압축을 풀고 새 GitHub repository를 생성
2. 프로젝트 파일 전체를 저장소에 업로드

## 4. Vercel 배포
1. Vercel에서 Add New > Project
2. GitHub 저장소를 Import
3. Environment Variables에 다음 3개 값을 등록

```env
NEXT_PUBLIC_SUPABASE_URL=Supabase의 Project URL
NEXT_PUBLIC_SUPABASE_ANON_KEY=Supabase의 anon/public key
SITE_PASSWORD=0613
```

4. Deploy 클릭
5. 배포 완료 후 `https://프로젝트이름.vercel.app` 주소 확인

## 5. 첫 접속 및 편집
1. 공개 주소 접속 → 사이트 비밀번호 `0613` 입력
2. `/admin` 접속 → Supabase에서 만든 소유자 이메일/비밀번호로 로그인
3. 명함 정보 수정 후 저장
4. 공개 주소에서 변경 내용 확인

## 6. NFC 등록
NFC Tools 앱에서:
1. Write 선택
2. Add a record > URL/URI
3. Vercel 공개 주소 입력 (예: `https://your-card.vercel.app`)
4. Write 실행
5. 다른 휴대폰으로 태그를 읽어 확인

NFC에는 `/admin`이 아니라 공개 명함 주소만 등록합니다.

## 보안
- 사이트 비밀번호 `0613`은 4자리라 추측하기 쉽습니다. 중요한 개인정보를 공개한다면 더 긴 비밀번호로 변경하세요.
- 사이트 비밀번호는 Vercel 환경 변수 `SITE_PASSWORD`에서 변경합니다.
- Supabase `service_role` 키는 절대 프런트엔드나 Vercel의 `NEXT_PUBLIC_` 변수로 등록하지 마세요.
- 공개 명함에 입력한 정보는 비밀번호를 아는 방문자에게 공개됩니다.
