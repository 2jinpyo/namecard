import { NextRequest, NextResponse } from "next/server";

async function validCookie(value: string | undefined, secret: string) {
  if (!value) return false;
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]
  );
  const [timestamp, signature] = value.split(".");
  if (!timestamp || !signature) return false;
  const issued = Number(timestamp);
  if (!Number.isFinite(issued) || Date.now() - issued > 7 * 24 * 60 * 60 * 1000 || issued > Date.now() + 60_000) return false;
  try {
    const normalized = signature.replace(/-/g, "+").replace(/_/g, "/");
    const padded = normalized + "=".repeat((4 - normalized.length % 4) % 4);
    const bytes = Uint8Array.from(atob(padded), c => c.charCodeAt(0));
    return await crypto.subtle.verify("HMAC", key, bytes, enc.encode(timestamp));
  } catch { return false; }
}

export async function middleware(req: NextRequest) {
  const secret = process.env.SITE_PASSWORD;
  if (!secret) return NextResponse.next();

  const path = req.nextUrl.pathname;
  // Unlock screen and unlock API must remain reachable without an access cookie.
  if (path === "/unlock" || path.startsWith("/api/unlock")) return NextResponse.next();

  const token = req.cookies.get("digital_card_access")?.value;
  if (await validCookie(token, secret)) return NextResponse.next();

  return NextResponse.redirect(new URL("/unlock", req.url));
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"]
};
